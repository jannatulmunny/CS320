import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("12345", "Jane", "Doe", "9876543210", "456 Second St");
        assertEquals("Jane", contactService.getContact("12345").getFirstName());
        assertEquals("Doe", contactService.getContact("12345").getLastName());
        assertEquals("9876543210", contactService.getContact("12345").getPhone());
        assertEquals("456 Second St", contactService.getContact("12345").getAddress());
    }

    @Test
    public void testAddDuplicateContact() {
        ContactService contactService = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("12345", "Jane", "Doe", "9876543210", "456 Second St");
        contactService.addContact(contact1);
        assertFalse(contactService.addContact(contact2)); // Adding duplicate should fail
    }
}